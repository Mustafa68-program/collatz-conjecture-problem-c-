#include <iostream>
using namespace std;
int main(){
int num1=0,num2=0,num3=0,num4=0;
cout<<"enter the password"<<endl;
cin>>num1>>num2>>num3>>num4;
if(num1==num2&&num2==num3&&num3==num4){
	cout<<"password is incorrect";
}	
else if(num1+1==num2&&num2+1==num3&&num3+1==num4){
cout<<"password is incorrect";
}
else if(num1-1==num2&&num2-1==num3&&num3-1==num4){
cout<<"password is incorrect";
}
else {
	cout<<"password is accepted";
}
return 0;
}