#include<iostream>
using namespace std;
int findChain(int x)
{
	int size=0;
	while(true)
	{
		if(x%2==0)
		{
			size++;
			x=x/2;
		}
		else if(x==1)
		{
			size++;
			break;
		}
		else
		{
			size++;
			x=3*x+1;
		}
	}
	return size;
}
int main()
{
	int size[1000];
	for(int i=1;i<=1000;i++)
	{
			size[i-1]=findChain(i);
		cout<<"The length of the chain for the given integer "<<i<<": "<<size[i-1]<<endl;
	}
	int largest=0,large;
	for(int i=0;i<1000;i++)
	{
		if(size[i]>largest)
		{
			largest=size[i];
			large=i+1;
		}
	}
	cout<<"The largest chain is "<<largest<<" of the integer "<<large;
	return 0;
} 